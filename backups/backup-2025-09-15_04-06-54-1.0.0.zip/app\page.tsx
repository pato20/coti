"use client"

import  from "../assets/js/productos"

export default function SyntheticV0PageForDeployment() {
  return < />
}